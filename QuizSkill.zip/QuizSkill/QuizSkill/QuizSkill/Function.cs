using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;
using Alexa.NET.Request;
using Alexa.NET.Request.Type;
using Alexa.NET.Response;
using Amazon.Lambda.Core;
using Newtonsoft.Json;

//https://www.youtube.com/watch?v=BPWmaYJIjCk&t=1590s

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace QuizSkill
{
    public class Function
    {

        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        /// 

        
        public const string INVOCATION_NAME = "quiz me";


        public string History1 = "Who was the first President of the United States? 1. Thomas Jefferson, 2. George Washington, 3. Abraham Lincoln, 4. John F. Kennedy; you can reply with, my answer is and the" +
            "number of your selection.";
        public string History1Answer = "2";

        public string Science1 = "What is the closest planet to the Sun? 1. Mars, 2. Mercury, 3. Venus, 4. Earth; you can reply with, my answer is" +
            "and the number of your selection";
        public string Science1Answer = "2";




        public SkillResponse FunctionHandler(SkillRequest input, ILambdaContext context)
        {

            var requestType = input.GetRequestType();
          

            //check for launch request
            if (requestType == typeof(LaunchRequest))
            {
                return MakeSkillResponse($"Welcome to the Quiz Me Skill, say the subject you would like to be quizzed on to continue!", false);
            }

            // check for intent request
            else if (requestType == typeof(IntentRequest))
            {
                var intent = input.Request as IntentRequest;
                if (intent.Intent.Name.Equals("SubjectIntent"))
                {
                    var subjectRequested = intent.Intent.Slots["course"].Value.ToLower();
                    if (subjectRequested == "history")
                    {

                        var outputText = $"You have requested questions on {subjectRequested}, Question 1: {History1}.";
                        return MakeSkillResponse(
                        outputText, false);    
                        
                    }
                    else if (subjectRequested == "science")
                    {
                        var text = $"You have requested questions on {subjectRequested}, Question 1: {Science1}";
                        return MakeSkillResponse(
                            text, false);
                    }
                    else
                    {
                        return MakeSkillResponse("Im sorry, I didnt get that", false);
                    }

                }
                else if (intent.Intent.Name.Equals("AnswerIntent"))
                {
                    var answerRequested = intent.Intent.Slots["answer"].Value.ToLower();

                        if (answerRequested == History1Answer)
                        {
                            return MakeSkillResponse(
                            $"That is correct!", true);
                        }
                       
                        else
                        {                            
                            return MakeSkillResponse(
                            "Wrong. Please try again", false);
                        }                    

                }
                else
                {
                    return MakeSkillResponse(
                        "I dont understand what you are saying. self destruction in 5. 4. 3. 2. 1.", true);
                }
               


            }
            else
            {
                return MakeSkillResponse(
                    $"I don't know how to handle this intent. Please say something like Alexa, {INVOCATION_NAME} on History.", true);
            }

           
        }



            private SkillResponse MakeSkillResponse(string outputSpeech, bool shouldEndSession, string repromptText = "Just say, quiz me about history to learn more. To exit, say, exit.")
            {
                var response = new ResponseBody
                {
                    ShouldEndSession = shouldEndSession,
                    OutputSpeech = new PlainTextOutputSpeech { Text = outputSpeech }

                };

                if (repromptText != null)
                {
                    response.Reprompt = new Reprompt() { OutputSpeech = new PlainTextOutputSpeech() { Text = repromptText } };
                }

                var skillResponse = new SkillResponse
                {
                    Response = response,
                    Version = "1.0"
                };
                return skillResponse;
            }
        

     
    }
}
