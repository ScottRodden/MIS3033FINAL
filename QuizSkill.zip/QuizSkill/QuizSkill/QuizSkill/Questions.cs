﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QuizSkill
{
    class Questions
    {
        public string QuestionID { get; set; }
        
        public string Subject { get; set; }

        public string AnswerLetter { get; set; }

        public string AnswerExplanation { get; set; }



    }
}
